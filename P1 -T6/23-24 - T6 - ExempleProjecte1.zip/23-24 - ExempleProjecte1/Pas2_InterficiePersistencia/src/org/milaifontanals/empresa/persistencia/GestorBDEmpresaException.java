/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.milaifontanals.empresa.persistencia;

/**
 *
 * @author Professor
 */
public class GestorBDEmpresaException extends Exception {

    public GestorBDEmpresaException(String message) {
        super(message);
    }

    public GestorBDEmpresaException(String message, Throwable cause) {
        super(message, cause);
    }

  
}
